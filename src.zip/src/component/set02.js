import data from '../data';

function Set02 (){
  return(
<div className="col-md-4">
<img src="https://codingapple1.github.io/shop/shoes2.jpg" width="80%" />
<h4>{data[1].title}</h4>
<p>{data[1].price}</p>
</div>
);
  }
export default Set02;

