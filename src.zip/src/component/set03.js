import data from '../data';

function Set03 (){
  return(
<div className="col-md-4">
<img src="https://codingapple1.github.io/shop/shoes3.jpg" width="80%" />
<h4>{data[2].title}</h4>
<p>{data[2].price}</p>
</div>
);
  }
export default Set03;
